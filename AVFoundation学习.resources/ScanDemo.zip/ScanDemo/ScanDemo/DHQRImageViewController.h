//
//  DHQRImageViewController.h
//  ScanDemo
//
//  Created by xiongan on 17/1/11.
//  Copyright © 2017年 大华. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DHQRImageViewController : UIViewController
@property NSString *text;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@end
